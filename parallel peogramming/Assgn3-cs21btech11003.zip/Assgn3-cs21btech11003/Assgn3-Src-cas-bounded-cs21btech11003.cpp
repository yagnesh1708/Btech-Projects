#include <iostream>

#include <chrono>

#include <pthread.h>

#include <random>

#include <fstream>

#include <ctime>

#include <sstream>

#include <cstring>

#include <iomanip>

#include <iostream>

#include <atomic>

#include <time.h>

#include <unistd.h>

#include <thread>

using namespace std;
using namespace chrono;
//For storing thread Id
struct thwork {
  int id;
};

//Lock variable
std::atomic < int > lock = 0;
int k, n;
double t1, t2;

bool * waiting;
double * waiting_time;
double * worst_waiting_time;
int count = 0;

int seed = chrono::system_clock::now().time_since_epoch().count();
default_random_engine generator(seed);

//Function to get system time
string currentDateTime() {
  time_t now = time(0);
  struct tm tstruct;
  char buf[80];
  tstruct = * localtime( & now);

  strftime(buf, sizeof(buf), "%X", & tstruct);

  return buf;
}

//Thread function
void * threads(void * arg) {

  thwork * ID = (thwork * ) arg;
  int Id = ID -> id;

  stringstream s1;
  string str1;
  s1 << "CS" << Id << ".txt";
  s1 >> str1;
  fstream file1;
  file1.open(str1, ios::out);

//generating exponential distriution random number
  exponential_distribution < double > delay1(1 / t1);
  int number1 = delay1(generator);
  exponential_distribution < double > delay2(1 / t1);
  int number2 = delay1(generator);

  int tm;
  int expected_value = 0;
  int new_value = 1;
  bool key;
  int j;
  for (int i = 0; i < k; i++) {

    milliseconds ms = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm = ms.count() - 1000 * s.count();
    file1 << Id << " CS request at " << currentDateTime() << ":" << tm << endl;

    //Lock
    waiting[Id] = true;
    key = true;
    while (waiting[Id] && key) {
      key = !(lock.compare_exchange_strong(expected_value, new_value));
      expected_value = 0;
    }

    waiting[Id] = false;

    milliseconds ms1 = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s1 = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm = ms1.count() - 1000 * s1.count();
    file1 << Id << " CS entry at " << currentDateTime() << ":" << tm << endl;
    
    //Calculating  waiting Time
    waiting_time[Id] = waiting_time[Id] + (ms1.count() - ms.count());

    //Calculating worst waiting Time
    if (worst_waiting_time[Id] < (ms1.count() - ms.count())) {
      worst_waiting_time[Id] = (ms1.count() - ms.count());
    }

    //Sleep Critical Section
    std::this_thread::sleep_for(chrono::milliseconds(number1));
    
    //CAS BOUNDED SPECIFIC
    j = (Id + 1) % n;
    while ((j != Id) && !waiting[j]) {
      j = (j + 1) % n;
    }
    if (j == Id)
      lock.store(0);
    else
      waiting[j] = false;

    milliseconds ms2 = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s2 = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm = ms2.count() - 1000 * s2.count();
    file1 << Id << " CS exit " << currentDateTime() << ":" << tm << endl;

    //Sleep Remainder section
    std::this_thread::sleep_for(chrono::milliseconds(number2));

  }

  return NULL;

}


int main() {

  int i, j;

  ifstream in ;
  in.open("inp-params.txt", ios::in);
  in >> n;
  in >> k;
  in >> t1;
  in >> t2;
//Initializing values to zero
  waiting_time = (double * ) malloc(sizeof(double) * n);
  for (int c = 0; c < n; c++) {
    waiting_time[c] = 0;
  }
  worst_waiting_time = (double * ) malloc(sizeof(double) * n);
  for (int c = 0; c < n; c++) {
    worst_waiting_time[c] = 0;
  }

  pthread_t th[n];
  thwork arr[n];
  waiting = (bool * ) malloc(sizeof(bool) * (n));
  for (int z = 0; z < n; z++) {
    waiting[i] = false;
  }
//Creating Threads
  for (i = 0; i < n; i++) {
    arr[i].id = i;
    pthread_create( & th[i], NULL, & threads, (void * ) & arr[i]);
  }
//waiting for threads to join
  for (i = 0; i < n; i++) {
    pthread_join(th[i], NULL);
  }

  //Creating output file
  fstream out;
  fstream in1;
  out.open("Bounded CAS.txt", ios::out);
  stringstream s1[n];
  string s2, s4, s5;

  for (int j = 0; j < n; j++) {

    s1[j] << "CS" << j << ".txt";
    s1[j] >> s2;
    in1.open(s2, ios::in);
    while (getline(in1, s5)) {
      out << s5 << endl;
    }
    in1.close();
    char arr[s2.length() + 1];
    strcpy(arr, s2.c_str());
    remove(arr);

  }
// Calculating average and worst case times
  double avg_waiting = 0;
  for (int c = 0; c < n; c++) {
    avg_waiting = waiting_time[c] + avg_waiting;
  }
  cout << avg_waiting / (n * k) <<" ";
  double worst_waiting_time2 = 0;
  for (int c = 0; c < n; c++) {

    if (worst_waiting_time[c] > worst_waiting_time2) worst_waiting_time2 = worst_waiting_time[c];
  }

cout << worst_waiting_time2<<" ";


  return 0;
}