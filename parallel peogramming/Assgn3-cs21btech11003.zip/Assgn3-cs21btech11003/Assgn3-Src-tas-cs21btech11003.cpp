#include <iostream>

#include <chrono>

#include <pthread.h>

#include <random>

#include <fstream>

#include <ctime>

#include <sstream>

#include <cstring>

#include <iomanip>

#include <iostream>

#include <atomic>

#include <time.h>

#include <unistd.h>

#include <thread>

using namespace std;
using namespace chrono;
//For storing thread Id
struct thwork {
  int id;
};

//Lock variable
atomic_flag lock = ATOMIC_FLAG_INIT;
int k, n;
double t1, t2;
double * waiting_time;
double * worst_waiting_time;

int seed = chrono::system_clock::now().time_since_epoch().count();
default_random_engine generator(seed);

//Function to get system time
string currentDateTime() {
  time_t now = time(0);
  struct tm tstruct;
  char buf[80];
  tstruct = * localtime( & now);

  strftime(buf, sizeof(buf), "%X", & tstruct);

  return buf;
}

//Thread function
void * threads(void * arg) {

  thwork * ID = (thwork * ) arg;
  int Id = ID -> id;

  stringstream s1;
  string str1;
  s1 << "TAS" << Id << ".txt";
  s1 >> str1;
  fstream file1;
  file1.open(str1, ios::out);


//generating exponential distriution random number
  exponential_distribution < double > delay1(1 / t1);
  int number1 = delay1(generator);
  exponential_distribution < double > delay2(1 / t1);
  int number2 = delay1(generator);

  int tm, tm1;

  for (int i = 0; i < k; i++) {

    milliseconds ms = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm = ms.count() - 1000 * s.count();
    file1 << Id << " CS request at " << currentDateTime() << ":" << tm << endl;
      
      //Lock
    while (lock.test_and_set());

    milliseconds ms1 = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s1 = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm1 = ms1.count() - 1000 * s1.count();
    file1 << Id << " CS entry at " << currentDateTime() << ":" << tm1 << endl;
    
    //Calculating Waiting Time
    waiting_time[Id] = waiting_time[Id] + (ms1.count() - ms.count());

   //Calculating worst waiting Time
    if (worst_waiting_time[Id] < (ms1.count() - ms.count())) {
      worst_waiting_time[Id] = (ms1.count() - ms.count());
    }

   //sleep Critical section 
   std::this_thread::sleep_for(chrono::milliseconds(number1));
   
    milliseconds ms2 = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s2 = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm = ms2.count() - 1000 * s2.count();
    file1 << Id << " CS exit " << currentDateTime() << ":" << tm << endl;

    //Sleep remainder section
    std::this_thread::sleep_for(chrono::milliseconds(number2));

    lock.clear();

  }

  return NULL;

}

int main() {

  int i, j;

  ifstream in ;
  in.open("inp-params.txt", ios::in);
  in >> n;
  in >> k;
  in >> t1;
  in >> t2;
  //Initializing values to zero
  waiting_time = (double * ) malloc(sizeof(double) * n);
  for (int c = 0; c < n; c++) {
    waiting_time[c] = 0;
  }
  worst_waiting_time = (double * ) malloc(sizeof(double) * n);
  for (int c = 0; c < n; c++) {
    worst_waiting_time[c] = 0;
  }
  pthread_t th[n];
  thwork arr[n];

//creating threads
  for (i = 0; i < n; i++) {
    arr[i].id = i;
    pthread_create( & th[i], NULL, & threads, (void * ) & arr[i]);
  }
//Waiting for them to finish
  for (i = 0; i < n; i++) {
    pthread_join(th[i], NULL);
  }

  //Creating output file
  fstream out;
  fstream in1;
  out.open("TAS.txt", ios::out);
  stringstream s1[n];
  string s2, s4, s5;

  for (int j = 0; j < n; j++) {

    s1[j] << "TAS" << j << ".txt";
    s1[j] >> s2;
    in1.open(s2, ios::in);
    while (getline(in1, s5)) {
      out << s5 << endl;
    }
    in1.close();
    char arr[s2.length() + 1];
    strcpy(arr, s2.c_str());
    remove(arr);

  }

//Calculating and printing average and worst case times
  double avg_waiting = 0;
  for (int c = 0; c < n; c++) {
    avg_waiting = waiting_time[c] + avg_waiting;
  }
  cout << avg_waiting / (n * k)<<" " ;

  double worst_waiting_time2 = 0;
  for (int c = 0; c < n; c++) {

    if (worst_waiting_time[c] > worst_waiting_time2) worst_waiting_time2 = worst_waiting_time[c];
  }

  cout << worst_waiting_time2<<" ";

  return 0;
}