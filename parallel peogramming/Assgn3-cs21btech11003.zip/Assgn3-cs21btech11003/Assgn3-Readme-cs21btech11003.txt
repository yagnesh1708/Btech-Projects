->The program needs input from "inp-params.txt" file, in the same directory.
->to compile tas code
         $g++ Assgn3-Src-tas-cs21btech11003.cpp -pthread
->To execute pthread code
         $./a.out
->to compile tas code
         $g++ Assgn3-Src-cas-cs21btech11003.cpp -pthread
->To execute pthread code
         $./a.out
->to compile tas code
         $g++ Assgn3-Src-cas-bounded-cs21btech11003.cpp -pthread
->To execute pthread code
         $./a.out 
->TAS.txt,CAS.txt and BoundedCAS.txt output files are created.
->Please give necesary permissions as codes generate and remove temporary text files.
