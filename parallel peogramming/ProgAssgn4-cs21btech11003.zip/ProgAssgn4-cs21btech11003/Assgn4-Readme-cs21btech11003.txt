->The program needs input from "inp-params.txt" file, in the same directory.
->to compile tas code
         $g++ Assgn4-Src-cs21btech11003.cpp -pthread
->to execute 
     $./a.out
->Please give necesary permissions as codes generate and remove temporary text files.
