#include <iostream>
#include <chrono>
#include <pthread.h>
#include <random>
#include <fstream>
#include <ctime>
#include <sstream>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <atomic>
#include <time.h>
#include <thread>
#include <unistd.h>
#include <semaphore.h>

using namespace std;
using namespace chrono;

//For storing thread Id
struct thwork {
  int id;
};

//Lock variable
sem_t Csem;
sem_t Csem2;
int k, n, c;
double t1, t2;
double * waiting_time;
double * raiding_time;
int *cars;

//seeding for random generator
int seed = chrono::system_clock::now().time_since_epoch().count();
default_random_engine generator(seed);

//Function to get system time
string currentDateTime() {
  time_t now = time(0);
  struct tm tstruct;
  char buf[80];
  tstruct = * localtime( & now);

  strftime(buf, sizeof(buf), "%X", & tstruct);

  return buf;
}

//Car threads
void *Cfunction(void *arg){

//generating exponential distribution random number
exponential_distribution < double > delay2(1 / t2);
  int number2 = delay2(generator);


//Car waiting time
    std::this_thread::sleep_for(chrono::milliseconds(number2));
    return NULL;
}


//Passenger Thread function
void * threads(void * arg) {

  thwork * ID = (thwork * ) arg;
  int Id = ID -> id;

  stringstream s1;
  string str1;
  s1 << "TAS" << Id << ".txt";
  s1 >> str1;
  fstream file1;
  file1.open(str1, ios::out);


//generating exponential distriution random number
  exponential_distribution < double > delay1(1 / t1);
  int number1 = delay1(generator);
   int tm, tm1,carnum;

     milliseconds ms = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm = ms.count() - 1000 * s.count();
    file1 <<"Passenger "<< Id << " entered museum at " << currentDateTime() << ":" << tm << endl;


  for (int i = 0; i < k; i++) {

  
//waiting time in museum 
     std::this_thread::sleep_for(chrono::milliseconds(number1));

         milliseconds ms3 = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s3 = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm = ms3.count() - 1000 * s3.count();
    file1 <<"Passenger "<< Id << " made request at " << currentDateTime() << ":" << tm << endl;

      
//Lock
    sem_wait(&Csem);
  
//Finding the next available car
    sem_wait(&Csem2);
    for(int h=0;h<c;h++){
      if(cars[h]==1) {cars[h]=0;carnum=h;break;}
    }
    sem_post(&Csem2);
    

    milliseconds ms1 = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s1 = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm1 = ms1.count() - 1000 * s1.count();
    file1 <<"Person "<<Id << " started riding Car "<<carnum<<" at " << currentDateTime() << ":" << tm1 << endl;

//Starting and finishing car ride 

    pthread_t Cthread;
    pthread_create(&Cthread,NULL, &Cfunction,NULL);
    pthread_join(Cthread,NULL);
    
    milliseconds ms2 = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s2 = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm = ms2.count() - 1000 * s2.count();
    file1 <<"Person "<<Id << " finished riding Car "<<carnum<<" at " << currentDateTime() << ":" << tm << endl;
    
   

    cars[carnum]=1;
    sem_post(&Csem);

//calculating riding time of each car
     raiding_time[Id] = raiding_time[Id] + (ms2.count() - ms1.count());

  }

   milliseconds ms4 = duration_cast < milliseconds > (system_clock::now().time_since_epoch());seconds s4 = duration_cast < seconds > (system_clock::now().time_since_epoch());
    tm = ms4.count() - 1000 * s4.count();
    file1 <<"Person "<<Id << " exit at " << currentDateTime() << ":" << tm << endl;


 //Calculating Waiting Time
//  cout<<(ms4.count() - ms.count())<<endl;
    waiting_time[Id] = waiting_time[Id] + (ms4.count() - ms.count());

  return NULL;

}

int main() {

  int i, j;

  ifstream in ;
  in.open("inp-params.txt", ios::in);
  in >> n;
  in >> c;
  in >> t1;
  in >> t2;
  in >> k;

//Initializing values to zero
  waiting_time = (double * ) malloc(sizeof(double) * n);
  for (int c1 = 0; c1 < n; c1++) {
    waiting_time[c1] = 0;
  }
  //Initializing values to zero
  raiding_time = (double * ) malloc(sizeof(double) * n);
  for (int c1 = 0; c1 < n; c1++) {
    raiding_time[c1] = 0;
  }
//initializing cars to avalialble
cars = (int * ) malloc(sizeof(int) * c);
  for (int c1 = 0; c1 < c; c1++) {
    cars[c1] = 1;
  }


//Declaring semaphore
sem_init(&Csem,0,c);
sem_init(&Csem2,0,1);

  pthread_t th[n];
  thwork arr[n];

//creating threads
  for (i = 0; i < n; i++) {
    arr[i].id = i;
    pthread_create( & th[i], NULL, & threads, (void * ) & arr[i]);
  }

//Waiting for them to finish
  for (i = 0; i < n; i++) {
    pthread_join(th[i], NULL);
  }

  //Creating output file
  fstream out;
  fstream in1;
  out.open("log.txt", ios::out);
  stringstream s1[n];
  string s2, s4, s5;

  for (int j = 0; j < n; j++) {

    s1[j] << "TAS" << j << ".txt";
    s1[j] >> s2;
    in1.open(s2, ios::in);
    while (getline(in1, s5)) {
      out << s5 << endl;
    }
    in1.close();
    char arr[s2.length() + 1];
    strcpy(arr, s2.c_str());
    remove(arr);

  }

//Calculating and printing average exit time
  double avg_waiting = 0;
  for (int c = 0; c < n; c++) {
    avg_waiting = waiting_time[c] + avg_waiting;
  }
 cout << avg_waiting/ n <<" " ;


//Calculating and printing average car riding time 
  double avg_riding = 0;
  for (int c = 0; c < n; c++) {
    avg_riding = raiding_time[c] + avg_riding;
  }
  cout << avg_riding/ k <<" " ;


  return 0;
}