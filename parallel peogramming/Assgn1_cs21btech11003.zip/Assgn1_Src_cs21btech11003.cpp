//AKKASANI YAGNESH REDDY
//CS21BTECH11003
#include<iostream>
#include<cstdlib>
#include<pthread.h>
#include<fstream>
#include<iomanip>
#include<ctime>
#include<chrono>
#include<sstream>
#include<cstring>
using namespace std;
using namespace chrono;

int *pn; //variable to store number of points checked by each thread
int n,k; //given number of points and threads

//Thread fucntion that generates n/k random numbers and checks whether in circle or not.
void *part(void *arg){
    
    int add = *(int *)arg;
    double x,y;
    int t=0;

      stringstream s1,s2;
      string str1,str2;
      s1<<"inc"<<add<<".txt";
      s1>>str1;
      s2<<"outc"<<add<<".txt";
      s2>>str2;

  fstream file1;
  fstream file2;
  file1.open(str1,ios::out );
  file2.open(str2,ios::out ); 

// checking their position and placing in them in temporary text files
         for(int i=0;i<n/k;i++){
      
        x=2*(double)rand()/(double)RAND_MAX-1;
        y=2*(double)rand()/(double)RAND_MAX-1;
          if((x*x+y*y)<=1) {t=t+1;
          file1<<"("<<x<<","<<y<<"),";
          }
          else {
            file2<<"("<<x<<","<<y<<"),";
          }
    }
        
        pn[add]=t;
   file1.close();
   file2.close();
    return NULL;
}


int main(){
    srand(time(0));
  
  int i;
  
  //Reading from input.txt file
  ifstream in;
  in.open("input.txt",ios::in); 
  in>>n;
  in>>k;
  in.close();
 pn=(int *)malloc(sizeof(int)*(k+1));

int arr[k];

auto start= high_resolution_clock::now();

 pthread_t th[k];

 //creating k threads
   for( i=0;i<k;i++){
    arr[i]=i;
    pthread_create(&th[i],NULL,&part,(void *) &arr[i]); 
    }
 //waiting fo threads to complete executing
 for(i=0;i<k;i++){
    pthread_join(th[i],NULL);
 }
double tot=0;
double pi;
 for(i=0;i<k;i++){
    tot=tot+pn[i];
}
//calculating pi
pi= 4 *tot/(double)n;
//calculating time taken in microseconds 
auto stop= high_resolution_clock::now();
auto time = duration_cast<microseconds>(stop-start);


fstream out;
fstream in1;
fstream in2;
out.open("output.txt",ios::out );
 stringstream s1[k],s3[k];
 string s2,s4,s5,s6;

 //Creating the output Log file
out<<"Time : "<<setprecision(10)<<(double)(time.count())<<" microseconds\n"<<endl;
out<<"Value Calculated = "<<setprecision(10)<<pi<<"\n"<<endl;
out<<"Log:"<<"\n"<<endl;

 for(int j=0;j<k;j++){

  out<<"Thread"<<j<<": "<<pn[j]<<", "<<n/k<<"\n"<<endl;
  out<<"Points inside circle :";
  s1[j]<<"inc"<<j<<".txt";
  s3[j]<<"outc"<<j<<".txt";
  s1[j]>>s2;s3[j]>>s4;
  in1.open(s2,ios::in);
  in2.open(s4,ios::in);
  getline(in1,s5);
  out<<s5<<"\n \n";
  out<<"Points inside square :";
  getline(in2,s6);
  out<<s6<<"\n \n \n \n";

in1.close();
in2.close();

char arr[s2.length()+1];
strcpy(arr,s2.c_str());
char arr2[s4.length()+1];
strcpy(arr2,s4.c_str());

//deleting temporary text files
remove(arr);
remove(arr2);
 }

free(pn);
out.close();

return 0;
}
