
->The program needs input from "input.txt" file, in the same directory. Two values separated by a space.
->to compile
         $g++ Assgn1_Src_cs21btech11003.cpp -pthread
->To execute
         $./a.out
->The program creates "output.txt" file.
->Please open the output file through VIM or VS code as most of the linux editors are crashing.
->Please give necessary permissions. As the program deletes som temporary files. 
