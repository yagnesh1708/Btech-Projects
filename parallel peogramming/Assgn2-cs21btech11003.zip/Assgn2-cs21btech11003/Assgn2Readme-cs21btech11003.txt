->The program needs input from "input.txt" file, in the same directory.Two values separated by a space followed by a sudoku.
->to compile pthread code
         $g++ Assgn2Srcpthread-cs21btech11003.cpp -pthread
->To execute pthread code
         $./a.out
->The program creates "output.txt" file.
->to compile openmp code
         $g++ Assgn2SrcOpenMp-cs21btech11003.cpp -fopenmp
->To execute openmp code
         $./a.out
->The program creates "output.txt" file.

->Please give necessary permissions. As the program deletes some temporary files. 
