//AKKASANI YAGNESH REDDY
//CS21BTECH11003
#include<iostream>
#include<cstdlib>
#include<pthread.h>
#include<fstream>
#include<iomanip>
#include<ctime>
#include<chrono>
#include<sstream>
#include<cstring>
#include<cmath>
using namespace std;
using namespace chrono;
struct thwork{

    int start;
    int end;
    int number;
    int order;
};

int *sudoku,n,k;
int *valid;
//function that checks for validity of rows or colums or grids
void *thread(void *arg){

struct thwork *a = (struct thwork *)arg;
int temp,temp2=1,check[n],check2=1,N=n,r,q;
for(int i=0;i<k;i++){
  check[i]=0;
}
 stringstream s1,s2;
      string str1,str2;
      s1<<"outc"<<a->order<<".txt";
      s1>>str1;
     fstream file1;
  file1.open(str1,ios::out );
  


if( a->number == 0 ) {return NULL;}
else{


for(temp=a->start;temp<=a->end;temp++){


    for(int i=0;i<n;i++){
  check[i]=0;
}
check2=1;
temp2=1;

//code that checks for validity of rows 
if(n<temp && temp<=(2*n)) {

  for(int i=(temp-1-n)*n;i<(temp-1-n)*n+n;i++){

 if(1<=sudoku[i]<=n) check[sudoku[i]-1]=1;
 else check2 = 0;

  }


}
//function that checks for validity of columns
else if((2*n)<temp && temp<=(3*n)){

  for(int i=((temp-(2*n)-1));i<=(((temp-(2*n)-1)))+((n-1)*n);i=i+n){


   if(1<=sudoku[i]<=n) check[sudoku[i]-1]=1;
   else check2 = 0;


}
}
//function that checks for validity of grids
else if(1<=temp && (temp)<=(n)){
  
q=((temp-1))/sqrt(n);r=((temp-1))%((int)sqrt(n));

for(int i = r*sqrt(n)+q*n*sqrt(n) ; i<=r*sqrt(n)+q*n*sqrt(n)+(sqrt(n)-1)*(n) ; i=i+n ){

  for(int j=i;j<i+sqrt(n);j++){

    if(1<=sudoku[j]<=n) check[sudoku[j]-1]=1;
 else check2 = 0;

  }
}


}

//Creating temporary output file
if (check2==0) {
  if(1<=temp && temp<=n) file1<<"Thread "<<a->order<<" checks grid "<<temp<<" and is invalid "<<endl;
else if((n)<temp && temp<=(2*n)) file1<<"Thread "<<a->order<<" checks row "<<(temp-n)<<" and is invalid "<<endl;
else if((2*n)<temp && temp<=(3*n)) file1<<"Thread "<<a->order<<" checks column "<<(temp-(2*n))<<" and is invalid "<<endl;

  valid[a->order]=0;temp2=0;}

else {

for(int p=0;p<n;p++){

  if(check[p]!=1) {
  if(1<=temp && temp<=n) file1<<"Thread "<<a->order<<" checks grid "<<temp<<" and is invalid "<<endl;
else if((n)<temp && temp<=(2*n)) file1<<"Thread "<<a->order<<" checks row "<<(temp-n)<<" and is invalid "<<endl;
else if((2*n)<temp && temp<=(3*n)) file1<<"Thread "<<a->order<<" checks column "<<(temp-(2*n))<<" and is invalid "<<endl;
  valid[a->order]=0;temp2=0;}
}

}
if(temp2==1){
if(1<=temp && temp<=n) file1<<"Thread "<<a->order<<" checks grid "<<temp<<" and is valid "<<endl;
else if((n)<temp && temp<=(2*n)) file1<<"Thread "<<a->order<<" checks row "<<(temp-n)<<" and is valid "<<endl;
else if((2*n)<temp && temp<=(3*n)) file1<<"Thread "<<a->order<<" checks column "<<(temp-(2*n))<<" and is valid "<<endl;}
}


}

return NULL;

}

int main(){
int i;
    

  ifstream in;
  in.open("input.txt",ios::in); 
  in>>k;
  in>>n;
  sudoku=(int *)malloc(sizeof(int)*(n*n));

  for(i=0;i<(n*n);i++){
      in>>sudoku[i];
  }
  in.close();

int tn[k];
  struct thwork arr[k];
  for(i=0;i<k;i++){
    tn[i]=(3*n)/k;
  }
  int r = (3*n)%k;
  for(i=0;i<k;i++){
    if(r>0){
    tn[i]=tn[i]+1;
    r=r-1;}
    arr[i].number=tn[i];
  }

  arr[0].start=1;
  arr[0].end=tn[0];

 for(i=1;i<k;i++){
    arr[i].start=arr[i-1].end + 1;
    arr[i].end=arr[i-1].end + tn[i];
}




 valid=(int *)malloc(sizeof(int)*k);
 for(i=0;i<(k);i++){
  valid[i]=-1;
 }

 pthread_t th[k];
 

auto start= high_resolution_clock::now();
//creating k threads

   for( i=0;i<k;i++){
    arr[i].order=i;
    pthread_create(&th[i],NULL,&thread,(void *) &arr[i]); 
    }

 //waiting fo threads to complete executing
  for(i=0;i<k;i++){
    pthread_join(th[i],NULL);
 }



//Creating output file
fstream out;
fstream in1;
out.open("output.txt",ios::out );
 stringstream s1[k];
 string s2,s4,s5;

 for(int j=0;j<k;j++){

  s1[j]<<"outc"<<j<<".txt"; s1[j]>>s2;
  in1.open(s2,ios::in);
 while( getline(in1,s5)){
  out<<s5<<endl;
 }
in1.close();
char arr[s2.length()+1];
strcpy(arr,s2.c_str());
remove(arr);

 }

 int b =0 ;
for(int v=0;v<k;v++) {
  if(valid[v]!=-1) {out<<"sudoku is invalid"<<endl;b=1;}
}
if(b==0) {out<<"sudoku is valid"<<endl;}


  auto stop= high_resolution_clock::now();
auto time = duration_cast<milliseconds>(stop-start);

 

  cout<<setprecision(10)<<(double)(time.count())<<" ";

   out<<setprecision(10)<<(double)(time.count())<<" milli seconds"<<endl;
return 0;

  

}